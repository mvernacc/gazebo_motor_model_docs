
11/29/15

This archive includes Vol 1 and Vol 2 datasets.

The archive is a copy of the webpages:
http://m-selig.ae.illinois.edu/props/propDB.html

After unzipping the archive, open propDB.html in your browser.

********************************************
Prof. Michael S. Selig
Dept. of Aerospace Engineering
University of Illinois at Urbana-Champaign
306 Talbot Laboratory
104 South Wright Street
Urbana, IL 61801-2935
(217) 244-5757
m-selig@illinois.edu
http://m-selig.ae.illinois.edu
********************************************  

